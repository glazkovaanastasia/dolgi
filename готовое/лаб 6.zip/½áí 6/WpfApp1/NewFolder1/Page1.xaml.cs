﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1.NewFolder1
{
	/// <summary>
	/// Логика взаимодействия для Page1.xaml
	/// </summary>
	public partial class Page1 : Page
	{
		public Page1()
		{
			InitializeComponent();
		}

		private void bthCalc_Click(object sender, RoutedEventArgs e)
		{
			double x = double.Parse(txtx1.Text);
			double y = double.Parse(txtx2.Text);
			double z = double.Parse(txtx3.Text);
			double v = (1 + Math.Pow(Math.Sin(x + y), 2)) / Math.Abs(x - ((2 * y) / (1 + Math.Pow(x, z) * Math.Pow(y, z) * Math.Pow(x, Math.Abs(y)) + (Math.Pow(Math.Cos(z)) * Math.Atan((1 / 2))))));
		}
	}
 }