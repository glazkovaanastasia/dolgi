﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace беброчка_хот
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Касаткин, Глазкова");
            string[] plot = { "морковь", "редис", "укроп", "картофель","Капуста"};
            string[] plot1={ "морковь", "редис" };
            string[] plot2={ "укроп", "морковь", "редис" };
            string[] plot3={ "картофель", "укроп", "морковь", "капуста", "редис" };
            Console.WriteLine("Овощи на каждом участке");
            Print_mnozh(plot1.Intersect(plot2).Intersect(plot3));
            Console.WriteLine("нет ни в одной грядке");
            Print_mnozh(plot.Except(plot1).Except(plot2).Except(plot3));
            Console.WriteLine("Есть хотя бы в одной грядке");
            Print_mnozh(plot1.Union(plot2).Union(plot3).
                Except(plot1.Intersect(plot2).Intersect(plot3)));
            Console.ReadKey();
            //////////////
            HashSet<char> rusAlphabet = new HashSet<char>();
            new HashSet<char> { 'б', 'в', 'г', 'д', 'ж', 'з', 'й' };
            Console.WriteLine("Вывести все согласные буквы");
            Print_mnozh((IEnumerable<string>)rusAlphabet);
            Console.ReadKey();
          
        }
        private static void Print_mnozh(IEnumerable<string> res)
        {
            foreach (string s in res)
                Console.WriteLine(s);
        }



        }
    }

